﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App1
{
    public partial class MainPage : ContentPage
    {
        string currentEntry = "";
        string lastOperator = "";
        double result = 0;

        public MainPage()
        {
            InitializeComponent();
        }
        private void OnNumberClicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            currentEntry += button.Text;
            InputBox.Text = currentEntry;
        }

        private void OnOperatorClicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            if (!string.IsNullOrEmpty(currentEntry))
            {
                if (result == 0)
                {
                    result = double.Parse(currentEntry);
                }
                else
                {
                    Calculate();
                }

                lastOperator = button.Text;
                currentEntry = "";
            }
        }

        private void OnEqualClicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentEntry))
            {
                Calculate();
                lastOperator = "";
                InputBox.Text = result.ToString();
                currentEntry = "";
            }
        }

        private void Calculate()
        {
            switch (lastOperator)
            {
                case "+":
                    result += double.Parse(currentEntry);
                    break;
                case "-":
                    result -= double.Parse(currentEntry);
                    break;
                case "×":
                    result *= double.Parse(currentEntry);
                    break;
                case "÷":
                    if (double.Parse(currentEntry) != 0)
                        result /= double.Parse(currentEntry);
                    else
                        InputBox.Text = "Error";
                    break;
                case "%":
                    result %= double.Parse(currentEntry);
                    break;
            }
        }

        private void OnClearClicked(object sender, EventArgs e)
        {
            currentEntry = "";
            lastOperator = "";
            result = 0;
            InputBox.Text = "0";
        }

        private void OnBackspaceClicked(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentEntry))
            {
                currentEntry = currentEntry.Remove(currentEntry.Length - 1);
                InputBox.Text = string.IsNullOrEmpty(currentEntry) ? "0" : currentEntry;
            }
        }
    }
}